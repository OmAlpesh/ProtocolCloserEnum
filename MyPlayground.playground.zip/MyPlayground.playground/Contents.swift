//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//Enumerations

enum DownloadStatus {
    case downloading
    case finished
    case failed
    case cancelled
}

var currentStatus = DownloadStatus.finished

switch currentStatus {
case .downloading:
    print("Downloading...")
    
case .finished:
    print("Just finished the download...")
    
case .failed:
    print("Failed to download the file...")
    
case .cancelled:
    print("The download is cancelled...")
}


enum Cloud {
    case cirrus
    case cumulus
    case altocumulus
    case stratus
    case cumulonimbus
}

enum WeatherCondition {
    case sunny(temperature: Float)
    case rainy(inchesPerHour: Float)
    case cloudy(cloudType: Cloud, windSpeed: Float)
}

let currentWeather = WeatherCondition.cloudy(cloudType: .cirrus, windSpeed: 4.2)

switch currentWeather {
case .sunny(let temperature):
    print("It is sunny and the temperature is \(temperature).")
    
case .rainy(let inchesPerHour):
    print("It is raining at a rate of \(inchesPerHour) inches per hour.")
    
case .cloudy(let cloudType, let windSpeed):
    print("It is cloudy; there are \(cloudType) clouds in the sky, and the wind speed is \(windSpeed).")
}

//Closures and Higher Order Functions

func myFunction(_ stringParameter: String, closureParameter: (String) -> Void) {
    closureParameter(stringParameter)
}

myFunction("Hello, world xxxx!", closureParameter: {(string) in
    print(string) //prints "Hello, world!"
})


myFunction("Hello, world!") {(string) in
    print(string) //prints "Hello, world!"
}

//Map
let mapNumbers = [1, 2, 3, 4, 5]
let doubledMapNumbers = mapNumbers.map { $0 + 2 }
print(doubledMapNumbers) //prints [2, 4, 6, 8, 10]

//Filter
let filterNumbers = [1, 2, 3, 4, 5]
let filteredNumbers = filterNumbers.filter { $0 > 3 }
print(filteredNumbers) //prints [4, 5]

//forEach
let forEachNumbers = [1, 2, 3, 4, 5]
forEachNumbers.forEach { print($0) } //prints one item of the array on each line

//Reduce
let reduceNumbers = [1, 2, 3, 4 ,5]
let reducedNumber = reduceNumbers.reduce(0) { $0 + $1 }
print(reducedNumber) //prints 15

//flatMap
let flatMapNumbers = [1, nil, 2, nil, 3, nil, 4, nil, 5]
let flatMappedNumbers = flatMapNumbers.flatMap { $0 }
print(flatMappedNumbers) //prints [1, 2, 3, 4, 5]


let chainNumbers = [1, nil, 2, nil, 3, nil, 4, nil, 5]
let doubledNumbersOver8 = chainNumbers.flatMap { $0 }.filter { $0 > 3 }.map { $0 * 2 }
print(doubledNumbersOver8) //prints [8, 10]


//Generics
func swapAnything<T>(_ a: inout T, _ b: inout T) {
    let temporaryB = b
    b = a
    a = temporaryB
}

var string1 = "Happy"
var string2 = "New Year"

swapAnything(&string1, &string2)
print(string1) // New Year
print(string2) // Happy

var bool1 = false
var bool2 = true

swapAnything(&bool1, &bool2)
print(bool1) // true
print(bool2) // false

struct GenericStack<Element> {
    private var storage = [Element]()
    
    mutating func push(_ item: Element) {
        storage.append(item)
    }
    
    mutating func pop() -> Element? {
        return storage.removeLast()
    }
}

var textStack = GenericStack<String>()
textStack.push("foo")
textStack.push("bar")
textStack.push("baz")

let textElement = textStack.pop()  // baz

var numStack = GenericStack<Int>()
numStack.push(10)
numStack.push(20)
numStack.push(30)

let numElement = numStack.pop()  // 30


//Protocols
//class Animal {
//    func makeSound() {
//        print("Implement me!")
//    }
//    
//    func move() {
//        print("Implement me!")
//    }
//}
//
//class Dog: Animal {
//    override func makeSound() {
//        print("Woof.")
//    }
//    
//    override func move() {
//        print("walk around like a dog")
//    }
//    
//    func bite() {
//        print("bite")
//    }
//}
//
//class Cat: Animal {
//    override func makeSound() {
//        print("Meow.")
//    }
//    
//    override func move() {
//        print("walk around like a cat")
//    }
//    
//    func scratch() {
//        print("scratch")
//    }
//}
//
//class Tiger: Animal {
//    func eat() {
//        print("Eat like a tiger")
//    }
//}
//
//let animal: Animal = Dog()
//animal.makeSound()   // Implement me!
//animal.move()        // Implement me!




protocol Animal {
    func makeSound()
    func move()
}

struct Dog: Animal {
    func makeSound() {
        print("Woof.")
    }
    
    func move() {
        print("walk around like a dog")
    }
    
    func bite() {
        print("bite")
    }
}

struct Cat: Animal {
    func makeSound() {
        print("Meow.")
    }
    
    func move() {
        print("walk around like a cat")
    }
    
    func scratch() {
        print("scratch")
    }
}

struct Tiger: Animal{
    
    func makeSound() {
        print("xxxxx.")
    }
    
    func move() {
        print("xxxxx")
    }
    
    func eat() {
        print("scratch")
    }
}

let animal: Animal = Tiger()
animal.makeSound()
animal.move()

















